using UnityEngine;
/*
 This script converts number gene values into actual vehicle inputs then applies those inputs the vehicle driving system.
 */

//Enumeration defining possible acceleration actions//
//How much thurst the vechiles should apply//
public enum AccelerationAction {  None = 0, Slow, Fast}

//Enumeration defining possible roation actions//
//Controls vehicle body rotation for maintaning balance and orientation//
public enum RotationAction {  None = 0, ForwardSlow, ForwardFast, BackwardSlow, BackwardFast}

public class VehicleAction
{
    public AccelerationAction acceleration;
    public RotationAction rotation;

    //Constructor creates action from integer gener values//
    //Gaem values are mapped to enum values by casting//
    public VehicleAction(int accelValue, int rotationValue)
    {
        acceleration = (AccelerationAction)accelValue;
        rotation = (RotationAction)rotationValue;
    }

    //Applies this action to the vehicles drive controller//
    //Converts abstract action enum into concrete control inputs//

    //Through the process://
    //Map acceleration enum to input value (0.0 to 1.0)//
    //Map rotation enum to input value (-1.0 to 1.0)//
    //Send the inputs to DriveCar controller//
    public void ApplyAction(DriveCar driveCar, Rigidbody2D carRB, float accelSpeed, float rotSpeed)
    {
        //Apply acceleration//
        float accelInput = 0f;
        switch(acceleration)
        {
            case AccelerationAction.Slow: accelInput = 0.5f; break;
            case AccelerationAction.Fast: accelInput = 1f; break;
        }

        //Apply rotation//
        float rotInput = 0f;
        switch(rotation)
        {
            case RotationAction.ForwardSlow: rotInput = 0.3f; break;
            case RotationAction.ForwardFast: rotInput = 1.0f; break;
            case RotationAction.BackwardSlow: rotInput = -0.3f; break;
            case RotationAction.BackwardFast: rotInput = -1.0f; break;
        }

        //Apply to vehicle//
        driveCar.SetInputs(accelInput, rotInput);
    }
}
