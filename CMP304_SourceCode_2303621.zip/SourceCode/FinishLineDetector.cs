using UnityEngine;

/*
The script monitors each vehicles x position and triggers level completion when they reach 3000m. 
It prevents dead vehicles from completing and resets between the generations.
 */

public class FinishLineDetector : MonoBehaviour
{
    //Set the end to be close to the end of the level length//
    [SerializeField] private float _finishLinePosition = 3000f;
    [SerializeField] private bool _enableFinishLine = true;
    [SerializeField] private Transform _vehicleTransform;

    private bool _hasTriggered = false;
    private bool _hasLoggedStart = false;

    //Unity start called when script instance is enabled//
    //Attempts to find the vehicle transforms if not assigned in inspector//
    //Looks for "Car" child game object for accurate position tracking//
    private void Start()
    {
        //if not assinged try to find the car child//
        if(_vehicleTransform == null)
        {
            Transform carTransform = transform.Find("Car");
            if(carTransform != null)
            {
                _vehicleTransform = carTransform;
            }
            else
            {
                //use this game obejcts transform//
                _vehicleTransform = transform;
            }
        }
    }

    //Unity update called once perframe//
    //Continuosly monitors vehicle position to detect finish lien crossing//
    private void Update()
    {
        if (_vehicleTransform == null)
        {
            return;
        }

        float currentPosition = _vehicleTransform.position.x;

        if (!_enableFinishLine || _hasTriggered) return;

        //Check if this vehicle has crossed the finish line//
        if (currentPosition >= _finishLinePosition)
        {

            AIVehicleController ai = GetComponent<AIVehicleController>();

            if (ai == null)
            {
                return;
            }
            if (ai.IsAlive())
            {
                _hasTriggered = true;
                ai.completedLevel();
            }
            else
            {
                Debug.LogWarning($"[FINISH-LINE-DEAD] {gameObject.name} crossed finish but already dead");
            }
        }
    }

    //Reset when vehicle is reinitialised//
    public void ResetTrigger()
    {
        _hasTriggered = false;
        _hasLoggedStart = false;
    }
}
