using UnityEngine;

//Enumeration defining slope categories for terrain//
//Slopes are calculated based on angle relative to horizontal//
public enum SlopeCategory {FlatDown = 0, FlatUp, ModerateDown, Moderateup, SteepDown, SteepUp}

//Enumartion defining velocity cateogries for speed//
//Velocity categories provide abstraction of vehcile speed for state representation//
public enum VelocityCategory {VerySlow = 0, Slow, Medium, Fast}

//Enumaeration defining fuel level categories//
//Fuel categories allow ai to consider fuel conservation in decision making//
public enum FuelCategory { Critical = 0, Low, Medium, High}

/*
This script converts raw sensor data into discrete categories, 
then creates a state index ranging from 0 � 95 representing the current situation.
 */
public class VehicleGameState
{
    public SlopeCategory currentSlope;
    public VelocityCategory currentVelocity;
    public FuelCategory currentFuel;

    //Calculates unique index 0-95 representing this state//
    //This index is used to look up  the appropirate action in DNA//

    //Break down of the Forumula//
    //Slope Contributes : 0, 16, 32, 48, 64 or 80//
    //Velocity contributes: 0, 4, 8 or 12//
    //Fuel contributes: 0, 1, 2 or 3//

    //Exmaple//
    //Moderate Down Slope + Medium velocity + hight fuel//
    //(2 * 16) + (2 * 4) + 3 = 43//
    public int GetStateIndex()
    {
        return (int)currentSlope * 16 + (int)currentVelocity * 4 + (int)currentFuel;
    }

    //Analyzes the current game environment and creates a state representation//
    //Uses raycasting for terrain analysis and componet queries for vehicle status//
    public static VehicleGameState AnalyzeState(Rigidbody2D carRB, float fuelPercent, Transform groundCheck, float checkDistance)
    {
        VehicleGameState state = new VehicleGameState();

        //Determine slope ahead using raycast//
        RaycastHit2D hit = Physics2D.Raycast(groundCheck.position, Vector2.down, checkDistance);
        if(hit.collider != null)
        {
            Vector2 groundNormal = hit.normal;
            float angle = Vector2.SignedAngle(Vector2.up, groundNormal);

            if (angle < -15f) state.currentSlope = SlopeCategory.SteepDown;
            else if (angle < -5f) state.currentSlope = SlopeCategory.ModerateDown;
            else if (angle < 5f) state.currentSlope = angle < 0 ? SlopeCategory.FlatDown : SlopeCategory.FlatUp;
            else if (angle < 15f) state.currentSlope = SlopeCategory.Moderateup;
            else state.currentSlope = SlopeCategory.SteepUp;
        }

        //Determine Velocity//
        float speed = carRB.linearVelocity.magnitude;
        if (speed < 2f) state.currentVelocity = VelocityCategory.VerySlow;
        else if (speed < 5f) state.currentVelocity = VelocityCategory.Slow;
        else if (speed < 8f) state.currentVelocity = VelocityCategory.Medium;
        else state.currentVelocity = VelocityCategory.Fast;

        //Determine Fuel//
        if (fuelPercent < 0.15f) state.currentFuel = FuelCategory.Critical;
        else if (fuelPercent < 0.35f) state.currentFuel = FuelCategory.Low;
        else if (fuelPercent < 0.65f) state.currentFuel = FuelCategory.Medium;
        else state.currentFuel = FuelCategory.High;

        return state;
    }
}
