using System;
using System.IO;
using System.Text;
using UnityEngine;

/*
 The script creates a timestamped CSV file in Assets/GA_Logs, 
 it then logs statistics for each generation and then adds a final summary at the end.
 */

public class GADataLogger
{
    private string _logFilePath;
    private StringBuilder _csvData;

    //Constructor initilaises logger and creates CSV file with headers//
    //Creates logs directory if it doesnt exist//
    //Generates unique filename with time stampe to prevent overwrites//
    public GADataLogger()
    {
        //Create logs folder if it doesnt exist//
        string logsFolder = Path.Combine(Application.dataPath, "GA_Logs");
        if(!Directory.Exists(logsFolder))
        {
            Directory.CreateDirectory(logsFolder);
        }

        //Create filename with timestamp//
        string timestamp = DateTime.Now.ToString("dd-MM-yyyy_HH-mm-ss");
        _logFilePath = Path.Combine(logsFolder, $"GA_Results_{timestamp}.csv");

        //Initialise CSV with headers//
        _csvData = new StringBuilder();
        _csvData.AppendLine("Generation,BestDistance,WorstDistance,AverageDistance,BestCheckpoints,BestTime,BestFitness,AverageFitness,Completions");

        //DEBUG LINE FOR TESTING//
        //Debug.Log($"[DATA LOGGER] Logging to: {_logFilePath}");
    }

    //Logs statistics for a completed generation to CSV file//
    //Appends a new row with all performance metrics//
    //Wrties immediatley to disk to preserve data in the event of an application crash//
    public void LogGeneration(int generation, float bestDist, float worstDist, float avgDist, int bestCheckpoints, float bestTime, float bestFitness, float avgFitness, int completionCount)
    {
        string line = generation.ToString() + ",";
        line += bestDist.ToString() + ",";
        line += worstDist.ToString() + ",";
        line += avgDist.ToString() + ",";
        line += bestCheckpoints.ToString() + ",";
        line += bestTime.ToString() + ",";
        line += bestFitness.ToString() + ",";
        line += avgFitness.ToString() + ",";
        line += completionCount.ToString();

        _csvData.AppendLine(line);

        //See what is being written//
        //Debug.Log($"[CSV-LINE] Writing: {line}");

        //Write to file immediatley//
        try
        {
            File.WriteAllText(_logFilePath, _csvData.ToString());
            //Debug.Log($"[DATA LOGGER] Generation {generation} logged - Best: {bestDist:F2}m, Avg: {avgDist:F2}m");

        }
        catch (Exception e)
        {
            Debug.Log($"[DATA LOGGER] Failed to write log: {e.Message}");
        }
    }

    //Appends a final summary section to the CSV file//
    //Called when all generations are complete//
    //Includes the configuration params and final stats//
    public void LogFinalSummary(string summary)
    {
        _csvData.AppendLine("");
        _csvData.AppendLine("=== FINAL SUMMARY ===");
        _csvData.AppendLine(summary);

        try
        {
            File.WriteAllText(_logFilePath, _csvData.ToString());
            Debug.Log($"[DATA LOGGER] Final summary saved to: {_logFilePath}");
        }
        catch (Exception e)
        {
            Debug.LogError($"[DATA LOGGER] Failed to write summary: {e.Message}");
        }
    }

    //retursn the full file path of the log file//
    public string GetLogFilePath()
    {
        return _logFilePath;
    }
}
