using TMPro;
using UnityEngine;

public class DisplayDistTxt : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI _distanceText;
    [SerializeField] private Transform _playerTrans;

    private Vector2 _startPosition;
    private bool _initialized = false;

    private void Start()
    {
        //Try find the player if not assigned//
        if (_playerTrans == null)
        {
            FindPlayer();
        }

        if (_playerTrans != null)
        {
            _startPosition = _playerTrans.position;
            _initialized = true;
        }
    }

    private void Update()
    {
        //if player not found yet keep trying//
        if (_playerTrans == null)
        {
            FindPlayer();

            if(_playerTrans != null)
            {
                _startPosition = _playerTrans.position;
                _initialized = true;
            }
            return;
        }

        if(!_initialized)
        { 
            return;
        }
        Vector2 distance = (Vector2)_playerTrans.position - _startPosition;
        distance.y = 0f;

        if(distance.x < 0)
        {
            distance.x = 0;
        }

        _distanceText.text = distance.x.ToString("F0") + "m";
        CheckpointManager.Instance.CheckPosition(distance.x);
    }

    private void FindPlayer()
    {
        //Find the vehicle by tag//
        GameObject player = GameObject.FindGameObjectWithTag("Player");

        if(player != null)
        {
            _playerTrans = player.transform;
            //Debug.Log("DisplayDisTxt: Found player!");
        }
    }
}

