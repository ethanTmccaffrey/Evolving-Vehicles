using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using UnityEngine;
using TMPro;
using UnityEngine.InputSystem.Controls;
using UnityEngine.UI;
using Unity.VisualScripting;

/*
This file manages the population of vehicles DNA, 
it runs generations that spawn the vehicle, simulate a round, evaluate the performance, evolve the AI then repeats the cycle.
It also tracks the statistics and logs the data for later use.
 */

public class GeneticAlgorithmManager : MonoBehaviour
{
    //GA configuration parameters//
    [Header("GA Parameters")]
    [SerializeField] private int _populationSize = 30;
    [SerializeField] private float _mutationRate = 0.10f;
    [SerializeField] private int _maxGenerations = 75;
    [SerializeField] private float _elitePercent = 0.3f;

    //Scene refernces//
    [Header("References")]
    [SerializeField] private GameObject _vehiclePrefab;
    [SerializeField] private Transform _spawnPoint;

    //Runtime configuration//
    [Header("Runtime settings")]
    [SerializeField] private float _maxGenerationTime = 120f;

    //Slider configuration//
    [Header("UI Sliders")]
    [SerializeField] private Slider _populationSlider;
    [SerializeField] private Slider _mutationSlider;
    [SerializeField] private Slider _maxGenSlider;
    [SerializeField] private Slider _eliteSlider;
    [SerializeField] private Slider _generationTimeSlider;


    [SerializeField] private TextMeshProUGUI _popSizeText;
    [SerializeField] private TextMeshProUGUI _mutationText;
    [SerializeField] private TextMeshProUGUI _maxGenText;
    [SerializeField] private TextMeshProUGUI _eliteText;
    [SerializeField] private TextMeshProUGUI _generationTimeText;

    //GA state variables//
    private List<VehicleDNA> _population;
    private List<float> _fitness;
    private System.Random _random;
    private int _currentGeneration = 0;

    //Simulation control//
    private bool _hasStarted = false;
    private bool _generationRunning = false;
    private float _generationTimer = 0f;
    private List<GameObject> _currentVehicles = new List<GameObject>();

    //External system references//
    private GAUIManager _uiManager;
    private GADataLogger _dataLogger;

    //unity start called once before first frame update//
    //Initialises the GA system and preps for execution//
    private void Start()
    {
        //Set up sliders//
        _populationSlider.minValue = 10;
        _populationSlider.maxValue = 50;
        _populationSlider.value = _populationSize;

        _mutationSlider.minValue = 0.05f;
        _mutationSlider.maxValue = 0.5f;
        _mutationSlider.value = _mutationRate;

        _maxGenSlider.minValue = 10;
        _maxGenSlider.maxValue = 100;
        _maxGenSlider.value = _maxGenerations;

        _eliteSlider.minValue = 0.1f;
        _eliteSlider.maxValue = 0.5f;
        _eliteSlider.value = _elitePercent;

        _generationTimeSlider.minValue = 30f;
        _generationTimeSlider.maxValue = 180f;
        _generationTimeSlider.value = _maxGenerationTime;

        _populationSlider.onValueChanged.AddListener(OnPopulationChanged);
        _mutationSlider.onValueChanged.AddListener(OnMutationChanged);
        _maxGenSlider.onValueChanged.AddListener(OnMaxGenChanged);
        _eliteSlider.onValueChanged.AddListener(OnEliteChanged);
        _generationTimeSlider.onValueChanged.AddListener(OnGenerationTimeChanged);

        //Update the text//
        UpdateAllLabels();

        _random = new System.Random();
        InitializePopulation();

        _uiManager = FindObjectOfType<GAUIManager>();

        Debug.Log("=== GA Ready ===");
        Debug.Log("Press Space to start");
        _dataLogger = new GADataLogger();

        //Disbale fuel controller for manaul play as not needed//
        FuelController fuelController = FindObjectOfType<FuelController>();
        if(fuelController != null )
        {
            fuelController.enabled = false;
            //DEBUG TEST LINE//
            //Debug.Log("FuelController disabled not needed for GA mode");
        }
    }

    //Slider callback functions//
    private void OnPopulationChanged(float value)
    {
        _populationSize = (int)value;
        _popSizeText.text = $"Population: {_populationSize}";

        if (!_hasStarted)
        {
            _population.Clear();
            InitializePopulation();

            //DEBUG TEST LINE//
           // Debug.Log($"[SLIDER] Population reinitialised to {_populationSize} individuals");
        }
    }
    private void OnMutationChanged(float value)
    {
        _mutationRate = value;
        //Show as a percentage//
        _mutationText.text = $"Mutation: {_mutationRate:P0}";
    }
    private void OnMaxGenChanged(float value)
    {
        _maxGenerations = (int)value;
        _maxGenText.text = $"Max Gens: {_maxGenerations}";
    }
    private void OnEliteChanged(float value)
    {
        _elitePercent = value;
        //Show as a percentage//
        _eliteText.text = $"Elite t: {_elitePercent:P0}";
    }
    private void OnGenerationTimeChanged(float value)
    {
        _maxGenerationTime = value;
        _generationTimeText.text = $"Gen Time: {_maxGenerationTime:F0}";
    }

    private void UpdateAllLabels()
    {
        _popSizeText.text = $"Population: {_populationSize}";
        _mutationText.text = $"Mutation: {_mutationRate:P0}";
        _maxGenText.text = $"Max Gens: {_maxGenerations}";
        _eliteText.text = $"Elite: {_elitePercent:P0}";
        _generationTimeText.text = $"Gen Time: {_maxGenerationTime:F0}";
    }


    //Creates the initial population of vehicles with random DNA//
    //Each vehicle starts with random genes mapping all game states to random actions, providing generic diversity for evolution to work with//
    void InitializePopulation()
    {
        _population = new List<VehicleDNA>();

        for (int i = 0; i < _populationSize; i++)
        {
            _population.Add(new VehicleDNA(_random));
        }

        //Debug.Log($"Initialised Population of {_populationSize} individuals");
    }

    //Unity ipdated called once per frame//
    //handles GA start trigger and manages generation timing and completion//
    private void Update()
    {
        //press space to start the Genetic Algorithm//
        if (!_hasStarted && Input.GetKeyDown(KeyCode.Space))
        {
            Debug.Log("=== Starting Genetic Algorithm ===");
            _hasStarted = true;

            //Tell game manager in AI training mode//
            GameManager.instance.SetAITrainingMode(true);
            //Debug.Log($"[GA-INIT] AI Training Mode Check: {GameManager.instance.IsAITraining()}");

            //Hide fuel bar UI//
            if(_uiManager != null)
            {
                _uiManager.OnGAStart();
            }
            
            StartGeneration();
            _generationRunning = true;
        }

        //Track the generation time//
        if (_generationRunning)
        {
            _generationTimer += Time.deltaTime;

            //Check if generation time limit has been reached//
            bool timeUp = _generationTimer >= _maxGenerationTime;
            bool allDead = AreVehiclesDead();

            if (timeUp || allDead)
            {
                Debug.Log($"Generation ended. Timer: {_generationTimer:F2}s, TimeUp: {timeUp}, AllDead: {allDead}");
                EndGeneration();
            }
        }
    }

    //Begins a new generation by spawning vehicles with current populations DNA//
    //resets the environment fuel cans and checkpoints to ensure fair evalutation//
    public void StartGeneration()
    {
        //Diable the sliders when GA is running//
        _populationSlider.interactable = false;
        _mutationSlider.interactable = false;
        _maxGenSlider.interactable = false;
        _eliteSlider.interactable = false;
        _generationTimeSlider.interactable = false;

        Debug.Log($"--- Generation {_currentGeneration + 1} ---");

        //clear previous generation//
        foreach(GameObject vehicle in _currentVehicles)
        {
            if(vehicle != null)
            {
                //Destroy previous gen vehicles immediatley//
                DestroyImmediate(vehicle);
            }
        }
        _currentVehicles.Clear();

        //DEBUG TEST LINE//
        Debug.Log("[START-GEN] Old vehicles destroyed, spawning new generation");

        //Respawn all fuel cans//
        FuelSpawner fuelSpawner = FindObjectOfType<FuelSpawner>();
        if (fuelSpawner != null)
        {
            fuelSpawner.RespawnFuelCans();
        }

        //Reset checkpoint manager//
        if(CheckpointManager.Instance !=null)
        {
            CheckpointManager.Instance.resetCheckpoints();
        }

        //Spawn all vehicles in population//
        for (int i = 0; i < _populationSize; i++)
        {
            GameObject vehicle = Instantiate(_vehiclePrefab, _spawnPoint.position, Quaternion.identity);
            AIVehicleController aiController = vehicle.GetComponent<AIVehicleController>();

            if (aiController != null)
            {
                aiController.Initialize(_population[i]);

                //reset Collision counter//
                DriverDeathFromHead deathScript = vehicle.GetComponent<DriverDeathFromHead>();
                if (deathScript != null)
                {
                    deathScript.ResetCollision();
                }

                _currentVehicles.Add(vehicle);
            }
            else
            {
                //Debug.LogError("Vehicle prefab is missing AIVehicleController component");
                Destroy(vehicle);
            }
        }
        _generationTimer = 0f;

        //Debug.Log("All Vehicles spawned - generation started!");
    }

    //Checks if all vehicles in the current generation are dead//
    //used to determine if generation should end early//
    private bool AreVehiclesDead()
    {
        if (_currentVehicles.Count == 0) return true;

        //Check if all vehicles are dead//
        foreach(GameObject vehicle in _currentVehicles)
        {
            if (vehicle != null)
            {
                AIVehicleController ai = vehicle.GetComponent<AIVehicleController>();
                if(ai != null && ai.IsAlive())
                {
                    //At least one vehicle is still alive//
                    return false;
                }
            }
        }
        //All dead or destroyed//
        return true;
    }

    //Ends the current generation and processes results//
    //Collects perfomrance data logs stats and initiates evolution if there are gens still left to run//
    private void EndGeneration()
    {
        //Prevent double execution//
        if (!_generationRunning) return;

        //Enable the sliders when GA is finished//
        _populationSlider.interactable = true;
        _mutationSlider.interactable = true;
        _maxGenSlider.interactable = true;
        _eliteSlider.interactable = true;
        _generationTimeSlider.interactable = true;

        _generationRunning = false;
        _generationTimer = 0f;

        //Collect data from the current vehicles//
        List<RunData> runDataList = new List<RunData>();

        foreach (GameObject vehicle in _currentVehicles)
        {
            if(vehicle != null)
            {
                AIVehicleController ai = vehicle.GetComponent<AIVehicleController>();
                if(ai != null)
                {
                    //Ensure data is collected//
                    ai.Die();
                    runDataList.Add(ai.GetRunData());
                }

                //Clean up the vehicles//
                Destroy(vehicle);
            }
        }

        _currentVehicles.Clear();

        //log best, worst and average performances//
        if (runDataList.Count > 0)
        {
            float bestDist = runDataList.Max(d => d.distanceTraveled);
            float worstDist = runDataList.Min(d => d.distanceTraveled);
            float avgDist = runDataList.Average(d => d.distanceTraveled);
            int completionCount = runDataList.Count(d => d.completedLevel);

            //Get additional statistics for logging//
            RunData bestRun = runDataList.OrderByDescending(d => d.distanceTraveled).First();
            int bestCheckpoint = (int)bestRun.checkpointsReached;
            float bestTime = bestRun.timeTaken;

            //Calculate fitness for logging//
            float bestFitness = CalculateFitness(bestRun);
            float avgFitness = runDataList.Average(d => CalculateFitness(d));

            //log to CSV file//
            if (_dataLogger != null)
            {
                //Debug.Log($"[CSV_WRITE] About to log: Gen={_currentGeneration}, Dist={bestDist:F2}, Worst={worstDist}, Avg={avgDist:F2}, Checkpoints={bestCheckpoint}, Time={bestTime:F2}, BestFit={bestFitness}, AvgFit={avgFitness:F2}, CompletedCount={completionCount}");
                _dataLogger.LogGeneration(_currentGeneration, bestDist, worstDist, avgDist, bestCheckpoint, bestTime, bestFitness, avgFitness, completionCount);
            }
        }

        //Evolve to next generation//
        _currentGeneration++;

        //Evolve to next generation//
        if (_currentGeneration < _maxGenerations)
        {
            EvolveNextGeneration(runDataList);

            //Start next generation after a short delay//
            Invoke("StartNextGeneration", 2f);
        }
        else
        {
            Debug.Log("=== GA Complete ===");

            //Exit AI training mode//
            GameManager.instance.SetAITrainingMode(false);

            //Show fuel bar again//
            if(_uiManager != null)
            {
                _uiManager.OnGAEnd();
            }

            if (_dataLogger != null)
            {
                string summary = $"Total Generations: {_currentGeneration}\n";
                summary += $"Population Size: {_populationSize}\n";
                summary += $"Mutation Rate: {_mutationRate}\n";
                summary += $"Max Generation Time: {_maxGenerationTime}s\n";
                summary += $"Log file location: {_dataLogger.GetLogFilePath()}";
                _dataLogger.LogFinalSummary(summary);
                //Debug.Log($"[DATA LOGGER] Complete! Results saved to: {_dataLogger.GetLogFilePath()}");
            }
        }
    }

    //Invoked after a delay to start the next generation//
    private void StartNextGeneration()
    {
        StartGeneration();
        _generationRunning = true;
    }

    //creates the next generation through evolutionary operations//
    //Implements eltism, selection, crossover and mutation//
    public void EvolveNextGeneration(List<RunData> runDataList)
    {
        //Calculate fitness for each individual//
        _fitness = new List<float>();

        for (int i = 0; i < Mathf.Min(runDataList.Count, _populationSize); i++)
        {
            _fitness.Add(CalculateFitness(runDataList[i]));
        }

        //Pad with zero fintess if needed//
        while (_fitness.Count < _populationSize)
        {
            _fitness.Add(0f);
        }

        //Create new population//
        List<VehicleDNA> newPopulation = new List<VehicleDNA>();

        //Keep to performers//
        int eliteCount = Mathf.FloorToInt(_populationSize * _elitePercent);
        List<int> sortedIndices = GetSortedFitnessIndices();

        for (int i = 0; i < eliteCount; i++)
        {
            newPopulation.Add(_population[sortedIndices[i]]);
        }

        //Fill rest with offspring//
        while (newPopulation.Count < _populationSize)
        {
            VehicleDNA parent1 = SelectParent();
            VehicleDNA parent2 = SelectParent();
            VehicleDNA child = parent1.Crossover(parent2);
            child.Mutate(_mutationRate);
            newPopulation.Add(child);
        }

        _population = newPopulation;
        //Log generation stats//
        LogGenerationStats();

    }

    //Calculate the fitness score fro a vehicles performance//
    //uses multi objective fitness function that combines (level completion, distance traveled, checkpoints reached, completion time, fuel efficiency, collision penalty)//
    private float CalculateFitness(RunData data)
    {
        //Multi-objective fitness function//
        float fitness = 0f;

        //if completed massive bonus//
        if(data.completedLevel)
        {
            fitness += 10000f;
            //reward speed of completion//
            fitness += (800f - data.timeTaken) * 100f;
            //reward fuel efficiency//
            fitness += data.fuelEfficiency * 50f;
        }
        else
        {
            //Survival based fitness for non completers//
            fitness += data.distanceTraveled * 50f;
            fitness += data.checkpointsReached * 300f;
        }

        //penalize collisions//
        fitness -= data.headCollisions * 200f;

        //heavy penalty for getting stuck//
        if(data.gotStuck)
        {
            //severe penalty proportional to time stuck//
            fitness -= data.timeStuck * 500f;

            //DEBUG TEST LINE//
            Debug.Log($"[FITNESS-STUCK-PENALTY] Distance: {data.distanceTraveled:F1}m, Stuck: {data.timeStuck:F1}s, Penalty: {data.timeStuck * 500f:F0}");

            //if vehicle barely moved and got stuck larger penalty//
            if(data.distanceTraveled < 50f)
            {
                fitness -= 5000f;

                //DEBUG TEST LINE//
                Debug.Log($"[FITNESS-STUCK-DEADEND] Vehicle only traveled {data.distanceTraveled:F1}m before getting stuck - additional 5000 penalty");
            }
        }

        //Penalty for slow progress //
        if(data.timeTaken > 5f && data.averageSpeed < 2f)
        {
            //vehicle was alive but barely moving//
            fitness -= 3000f;

            //DEBUG TEST LINE//
            Debug.Log($"[FITNESS-SLOW-PENALTY] Avg speed {data.averageSpeed:F2} m/s over {data.timeTaken:F1}s - 3000 penalty");

        }

        return Mathf.Max(0f, fitness);
    }

    //Selects a parent for corssover using tournament selection//
    //Torunament selcection maintains selection pressure while allowing diversity//
    private VehicleDNA SelectParent()
    {
        //Tournament slection//
        int tournamentSize = Mathf.Min(5, _populationSize);
        int bestIndex = _random.Next(0, _populationSize);
        float bestFitness = _fitness[bestIndex];

        //Run tournament compare fitness fo random individuals//
        for (int i = 1; i < tournamentSize; i++)
        {
            int randomIndex = _random.Next(0, _populationSize);
            //if this competitor is better update winner//
            if (_fitness[randomIndex] > bestFitness)
            {
                bestIndex = randomIndex;
                bestFitness = _fitness[randomIndex];
            }
        }
        //Return DAN of torunament winner//
        return _population[bestIndex];
    }

    //Returns indices of population sorted by fitness best to worst order//
    //used for elitism//
    private List<int> GetSortedFitnessIndices()
    {
        return _fitness
            .Select((fit, index) => new { Fitness = fit, Index = index })
            .OrderByDescending(x => x.Fitness)
            .Select(x => x.Index)
            .ToList();
    }

    //Logs stats summary of current generations fitness//
    private void LogGenerationStats()
    {
        float avgFitness = _fitness.Average();
        float maxFitness = _fitness.Max();
        float minFitness = _fitness.Min();

        //DEBUG TEST LINE//
       // Debug.Log($"Generation {_currentGeneration}: Avg={avgFitness:F2}, max={maxFitness:F2}, Min={minFitness:F2}");
    }

    //Public getters for UI//
    public int GetCurrentGeneration() => _currentGeneration;
    public int GetMaxGenerations() => _maxGenerations;
    public float GetGenerationTimer() => _generationTimer;
    public float GetMaxGenerationTime() => _maxGenerationTime;
    public int GetPopulationSize() => _populationSize;

    //Retursn count of currently alive vehicles//
    public int GetAliveVehicleCount()
    {
        int count = 0;
        foreach(GameObject vehicle in _currentVehicles)
        {
            if(vehicle != null)
            {
                AIVehicleController ai = vehicle.GetComponent<AIVehicleController>();
                if(ai != null && ai.IsAlive())
                {
                    count++;
                }
            }
        }
        return count;
    }

    //Retursn best distance achieved in current generation//
    public float GetBestCurrentDistance()
    {
        float best = 0f;
        foreach (GameObject vehicle in _currentVehicles)
        {
            if(vehicle != null)
            {
                float dist = vehicle.transform.position.x;
                if (dist > best) best = dist;
            }
        }
        return best;
    }

    //returs count of vehicles that have completed the level//
    public int GetCompletedCount()
    {
        int count = 0;
        foreach(GameObject vehicle in _currentVehicles)
        {
            if(vehicle != null)
            {
                AIVehicleController ai = vehicle.GetComponent<AIVehicleController>();
                if (ai != null)
                {
                    RunData data = ai.GetRunData();
                    if (data.completedLevel)
                    {
                        count++;
                    }
                }
            }
        }
        return count;
    }
}



