using UnityEngine;
using TMPro;


public class GAUIManager : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI _generationText;
    [SerializeField] private TextMeshProUGUI _timerText;
    [SerializeField] private TextMeshProUGUI _aliveCountText;
    [SerializeField] private TextMeshProUGUI _bestDistanceText;
    [SerializeField] private TextMeshProUGUI _completionsText;

    //Reference to hide it during GA//
    [SerializeField] private GameObject _fuelBarUI;

    private GeneticAlgorithmManager _gaManager;

    private void Start()
    {
        _gaManager = FindObjectOfType<GeneticAlgorithmManager>();
    }

    private void Update()
    {
        if( _gaManager == null )
        {
            return;
        }

        //update generation number//
        if (_generationText != null)
        {
            _generationText.text = $"Generation: {_gaManager.GetCurrentGeneration() + 1} / {_gaManager.GetMaxGenerations()}";
        }

        //Update timer//
        if( _timerText != null )
        {
            float timer = _gaManager.GetGenerationTimer();
            float maxTime = _gaManager.GetMaxGenerationTime();
            _timerText.text = $"time: {timer:F1}s / {maxTime:F0}s";
        }

        //Update alive count//
        if(_aliveCountText != null)
        {
            int aliveCount = _gaManager.GetAliveVehicleCount();
            int totalCount = _gaManager.GetPopulationSize();
            _aliveCountText.text = $"Alive: {aliveCount} / {_gaManager.GetPopulationSize()}";
        }
        //Update the best distance from the generation//
        if(_bestDistanceText != null)
        {
            float bestDist = _gaManager.GetBestCurrentDistance();
            _bestDistanceText.text = $"Best Distance: {bestDist:F1}m";
        }
        //Update completions counts//
        if(_completionsText != null)
        {
            int completions = _gaManager.GetCompletedCount();
            _completionsText.text = $"Completed: {completions}";
        }
        
    }

    //When GA starts hide the fuel bar//
    public void OnGAStart()
    {
        if(_fuelBarUI != null)
        {
            _fuelBarUI.SetActive(false);
        }
    }

    //Show fuel bar when GA ends//
    public void OnGAEnd()
    {
        if(_fuelBarUI != null)
        {
            _fuelBarUI.SetActive(true);
        }
    }
}
