using UnityEngine;
using UnityEngine.UI;

public class FuelController : MonoBehaviour
{
    public static FuelController instance;

    [SerializeField] private Image _fuelImage;
    [SerializeField] private float _fuelDrainSpeed = 10f;
    [SerializeField] private float _maxFuelAmount = 100f;
    [SerializeField] private Gradient _fuelGradient;

    private float _currentFuelAmount;
    private bool _hasCalledGameOver = false;

    private void Awake()
    {
        if(instance == null)
        {
            instance = this; 
        }
    }

    private void Start()
    {
        _currentFuelAmount = _maxFuelAmount;
        _hasCalledGameOver = false;
        UpdateUI();
    }
    void Update()
    {
        //each vehicle has its own fuel//
        if(GameManager.instance != null && GameManager.instance.IsAITraining())
        {
            //Exit during GA mode//
            return;
        }

        _currentFuelAmount -= Time.deltaTime * _fuelDrainSpeed;
        UpdateUI();

        if(_currentFuelAmount <= 0f && !_hasCalledGameOver)
        {
            _hasCalledGameOver = true;
            //Debug.Log("FuelController: Out of fuel, calling GameVoer()");
            GameManager.instance.GameOver();
        }
    }
    private void UpdateUI()
    {
        _fuelImage.fillAmount = (_currentFuelAmount / _maxFuelAmount);
        _fuelImage.color = _fuelGradient.Evaluate(_fuelImage.fillAmount);
    }

    public void FillFuel()
    {
        _currentFuelAmount = _maxFuelAmount;
        _hasCalledGameOver = false;
        UpdateUI();
    }

    public float GetFuelPercent()
    {
        return _currentFuelAmount / _maxFuelAmount;
    }

    public void ResetFuel()
    {
        _currentFuelAmount = _maxFuelAmount;
        _hasCalledGameOver = false;
        UpdateUI();
    }

}
