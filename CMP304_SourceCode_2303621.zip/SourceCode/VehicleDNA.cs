using UnityEngine;
using System.Collections.Generic;
using JetBrains.Annotations;

public class VehicleDNA
{
    public List<int> genes;
    //6 slopes * 4 velocities * 4 fuel levels//
    private int numStates = 96;
    private System.Random random;

    public VehicleDNA(System.Random rand)
    {
        random = rand;
        genes = new List<int>();

        //Initialise with random genes//
        //First 96 values are acceleration actions 0-2//
        for(int i = 0; i < numStates; i++)
        {
            //AccellerationAction has 3 values//
            genes.Add(random.Next(0, 3));
        }

        //next 96 values are rotation actions 0-4//
        for(int i = 0;i < numStates; i++)
        {
            //RotationAction has 5 values//
            genes.Add(random.Next(0, 5));
        }

        //Debug.Log($"VehicleDNA created with {genes.Count} genes (Expected 192)");
    }

    public VehicleAction GetActionForState(int stateIndex)
    {
        //Safety bound checking//
        if(stateIndex < 0 || stateIndex >= numStates)
        {
            Debug.LogError($"invalid state Index: {stateIndex}. Should be 0-{numStates - 1}. Clmaping to valid range.");
            stateIndex = Mathf.Clamp(stateIndex, 0, numStates - 1);
        }

        //Additional check for genes list//
        if(genes == null || genes.Count < numStates * 2)
        {
            Debug.LogError($"Genes list is invalid Count: {genes?.Count ?? 0}. Expected: {numStates * 2}");
            return new VehicleAction(0, 0);

        }
        int accelGene = genes[stateIndex];
        int rotGene = genes[stateIndex + numStates];
        return new VehicleAction(accelGene, rotGene);
    }

    //Crossover//
    public VehicleDNA Crossover(VehicleDNA partner)
    {
        VehicleDNA child = new VehicleDNA(random);
        child.genes.Clear();

        //Single point crossover//
        int crossoverPoint = random.Next(0, genes.Count);

        for (int i = 0; i < genes.Count; i++)
        {
            if (i < crossoverPoint)
            {
                child.genes.Add(this.genes[i]);
            }
            else
            {
                child.genes.Add(partner.genes[i]);
            }

        }
        return child;
    }


    //Mutation//
    public void Mutate(float mutationRate)
    {
        for (int i = 0; i < genes.Count; i++)
        {
            if(random.NextDouble() < mutationRate)
            {
                //Mutate this game//
                if(i < numStates)
                {
                    //Acceleration gene//
                    genes[i] = random.Next(0, 3);
                }
                else
                {
                    genes[i] = random.Next(0, 5);
                }
            }
        }
    }
}
