using UnityEngine;

/*
This script applies torque to the wheels and car body based on the given inputs. 
It also handles the switching between manual controls and AI control.
 */

public class DriveCar : MonoBehaviour
{
    [SerializeField] private Rigidbody2D _frontTireRB;
    [SerializeField] private Rigidbody2D _carRB;
    [SerializeField] private Rigidbody2D _backTireRB;
    [SerializeField] private float _speed = 150;
    [SerializeField] private float _rotationSpeed = 300f;
    [SerializeField] private float _bodyRotationSpeed = 30f;

    [SerializeField] private bool _enableSelfRighting = true;
    [SerializeField] private float _selfRightingStrength = 30f;
    [SerializeField] private float _selfRightingThreshold = 45f;

    private float _rotationInput;
    private float _moveInput;

    private bool _isAiControlled = false;
    private float _aiMoveInput = 0f;
    private float _aiRotInput = 0f;

    //Unity update called once per frame//
    //Reads input based on current control mode (Ai or Mannual)//
    void Update()
    {
        if(_isAiControlled)
        {
            //Use inputs set by AIVehicleOController//
            _moveInput = _aiMoveInput;
            _rotationInput = _aiRotInput;
        }
        else
        {
            //read unity input system//
            _moveInput = Input.GetAxisRaw("Horizontal");
            _rotationInput = Input.GetAxisRaw("Vertical");
        }
    }

    //Unity fixed updates called at fixed time intervals for physics calculations//
    //Applies torque forces to wheels and body based on current input values//
    private void FixedUpdate()
    {
        _frontTireRB.AddTorque(-_moveInput * _speed * Time.fixedDeltaTime);
        _backTireRB.AddTorque(-_moveInput * _speed * Time.fixedDeltaTime);
        _carRB.AddTorque(_moveInput * _rotationSpeed * Time.fixedDeltaTime);
        _carRB.AddTorque(_rotationInput * _bodyRotationSpeed * Time.fixedDeltaTime);

        //Self righting system to prevent getting stuck//
        if(_enableSelfRighting)
        {
            ApplySelfRightingForce();
        }
    }

    private void ApplySelfRightingForce()
    {
        //Get current roation//
        float currentRotation = transform.rotation.eulerAngles.z;

        //Convert to -180 to 180 range//
        if(currentRotation > 180f)
        {
            currentRotation -= 360;
        }

        //only applying righting force if tilted beyond threshold//
        if (Mathf.Abs(currentRotation) > _selfRightingThreshold)
        {
            //Only apply righting torque//
            float tiltFactor = (Mathf.Abs(currentRotation) - _selfRightingThreshold) / (90f - _selfRightingThreshold);
            tiltFactor = Mathf.Clamp01(tiltFactor);

            //Apply torque in opposite direction to tilt//
            float rightingTorque = -Mathf.Sign(currentRotation) * _selfRightingStrength * tiltFactor;
            _carRB.AddTorque(rightingTorque * Time.fixedDeltaTime);

            //DEBUG TEST LINE//
            //Debug.DrawRay(transform.position, Vector3.up * 2f, Color.yellow);
        }
    }

    //Sets the control mode for this vehicle//
    public void SetAIControlled(bool controlled)
    {
        _isAiControlled = controlled;
    }

    //Sets the control inputs for AI control mode//
    public void SetInputs(float moveInput, float rotInput)
    {
        _aiMoveInput = moveInput;
        _aiRotInput = rotInput;
    }
}
