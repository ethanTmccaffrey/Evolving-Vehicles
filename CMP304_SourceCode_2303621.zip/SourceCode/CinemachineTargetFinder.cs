using UnityEngine;
using Unity.Cinemachine;

public class CinemachineTargetFinder : MonoBehaviour
{
    private CinemachineCamera _CinemachineCamera;
    private GameObject _currentTarget;

    private void Start()
    {
        _CinemachineCamera = GetComponent<CinemachineCamera>();
        if( _CinemachineCamera == null )
        {
            Debug.LogError("CinemachineTargetFinder: No CinemachineCamera component found!");
        }
    }

    private void LateUpdate()
    {
        if( _CinemachineCamera == null ) return;

        //Always check if target is null or destroyed//
        if (_currentTarget == null)
        {
            GameObject player = GameObject.FindGameObjectWithTag("Player");

            if (player != null)
            {
                //Set the tracking target using the Tracking Property//
                _CinemachineCamera.Follow = player.transform;
                _CinemachineCamera.LookAt = player.transform;

                _currentTarget = player;
                //Debug.Log("Cinemachine: Successfully set tracking set to " + player.name);
            }
        }
    }
}
