using UnityEngine;

public class ManualCameraController : MonoBehaviour
{
    [SerializeField] private float _moveSpeed = 20f;
    [SerializeField] private float _zoomSpeed = 5f;
    [SerializeField] private float _minZoom = 5;
    [SerializeField] private float _maxZoom = 5;

    private Camera _camera;

    private void Start()
    {
        _camera = GetComponent<Camera>();
    }

    private void Update()
    {
        //WASD or Arrow keys to move camera//
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");

        Vector3 moveDirection = new Vector3(horizontal, vertical, 0);
        transform.position += moveDirection * _moveSpeed * Time.deltaTime;

        //Mouse scrool wheel to zoom//
        float scroll = Input.GetAxis("Mouse ScrollWheel");
        if(_camera != null && scroll != 0)
        {
            _camera.orthographicSize -= scroll * _zoomSpeed;
            _camera.orthographicSize = Mathf.Clamp(_camera.orthographicSize, _minZoom, _maxZoom);
        }

        //Holding left shif speeds up camera//
        if(Input.GetKey(KeyCode.LeftShift))
        {
            transform.position += moveDirection * _moveSpeed * 2f * Time.deltaTime;
        }
    }
}
