using UnityEngine;
using UnityEngine.SceneManagement;

/*
This script tracks whether a game is in manual play or GA training mode,
it handles the game over state for manual play and tracks the run time.
 */

public class GameManager : MonoBehaviour
{
    //Static refernce to the single GameManger instance//
    //Accessible from any script via GameManger instance//
    public static GameManager instance;

    [SerializeField] private GameObject _gameOverCanvas;
    private float _runTime = 0f;

    //Track if in AI training mode//
    private bool _isAITraining = false;

    //Unity Awake called before start//
    //Sets up singleton instance and ensures normal time scale//
    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }

        Time.timeScale = 1f;
    }

    //Unity update called once per frame//
    //Tracks total gameplay time when game is not paused//
    private void Update()
    {
        if (Time.timeScale > 0)
        {
            _runTime += Time.deltaTime;
        }
    }

    //Setsa the ai training mode state//
    //Called by GA manager when starting and stopping GA training//
    public void SetAITrainingMode(bool isTraing)
    {
        _isAITraining = isTraing;
        Debug.Log($"AI Training Mode: {_isAITraining}");
    }

    //Handles game over state based on current mode//
    public void GameOver()
    {
        //Find the AI controller and mark it as dead//
        AIVehicleController ai = FindObjectOfType<AIVehicleController>();
        if (ai != null)
        {
            ai.Die();
        }

        //Only show game over UI if not in AI training mode//
        if (!_isAITraining)
        {
            _gameOverCanvas.SetActive(true);
            Time.timeScale = 0f;
            Debug.Log("Game Over - Manual Play");
        }
    }

    //Restarts the current scene//
    //resets run time, ensurestime is flowing and reloads the scene//
    public void RestartGame()
    {
        _runTime = 0f;
        Time.timeScale = 1f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    //retursn the total run time since scene loaded//
    public float GetRunTime() => _runTime;

    //Retursn weither currentyl in AI training mode//
    public bool IsAITraining()
    {
        return _isAITraining;
    }

}
