using UnityEngine;
/*
Each vehicle has its own fuel tank which is separate from the global fuel UI used in manual mode, 
The script controls the fuel draining over time during GA training and then kills any vehicle that runs out of fuel.
 */
public class VehicleFuelController : MonoBehaviour
{
    [SerializeField] private float _fuelDrainSpeed = 10f;
    [SerializeField] private float _maxFuelAmount = 100f;

    private float _currentFuelAmount;
    private bool _hasCalledGameOver = false;

    //unity start called when script instance is enabled//
    //Initialises fuel to full capacity at the start fo each run//
    private void Start()
    {
        _currentFuelAmount = _maxFuelAmount;
        _hasCalledGameOver = false;
    }

    //Unity update called once per frame//
    //Continously drains fuel and check for depletion//
    private void Update()
    {
        //only drain fuel if this vehicle is active//
        _currentFuelAmount -= Time.deltaTime * _fuelDrainSpeed;

        //Check if out of fuel//
        if(_currentFuelAmount <= 0 && !_hasCalledGameOver)
        {
            _hasCalledGameOver = true;

            //DEBUG TEST LINE//
           // Debug.Log($"[FuelCategory-DEATH] {gameObject.name} out of fuel at {transform.position.x}m");

            //Mark this vehicle as dead not global game over//
            AIVehicleController ai = GetComponent<AIVehicleController>();

            if(ai != null )
            {
                ai.Die();
            }
        }
    }

    //Refills fuel to maximum capacity//
    //Resets the game over flag to allowed continued operation//
    public void FillFuel()
    {
        //DEBUG TEST LINE//
        //Debug.Log($"[FUEL-REFIL] {gameObject.name} refiled fuel at {transform.position.x}m");

        _currentFuelAmount = _maxFuelAmount;
        _hasCalledGameOver = false;
    }

    //returns current fuel level as a percentage (0.0 t0 1.0)//
    public float GetFuelPercent()
    {
        return _currentFuelAmount/ _maxFuelAmount;
    }

    //Resets fuel to maximum and clears game over flag//
    //used when reinitialising vehicles for new generations//
    public void ResetFuel()
    {
        _currentFuelAmount = _maxFuelAmount;
        _hasCalledGameOver = false;
    }
}
