using UnityEngine;

/*
This script detects when the drivers head hits the ground, counts the collisions and triggers the death.
 */


public class DriverDeathFromHead : MonoBehaviour
{
    private int _collisionCount = 0;

    //unity collision callback called when this collider touches another collider//
    //Checks if collision is with gorund and handles death appropriately//
    private void OnCollisionEnter2D(Collision2D collision)
    {
        //If collided objected has tage ground//
        if (collision.gameObject.CompareTag("Ground"))
        {
            _collisionCount++;

            //DEBUG TEST LINE//
            //Debug.Log($"[CRASH] {gameObject.name} head hit ground at {transform.position.x}m");

            if (GameManager.instance != null && GameManager.instance.IsAITraining())
            {
                AIVehicleController ai = GetComponent<AIVehicleController>();
                if (ai != null)
                {
                    //Kills only this vehicle//
                    ai.Die();
                }
            }
            else
            {
                //Single player mode//
                GameManager.instance.GameOver();
            }
        }
    }
    
    //returns the total number of head collsiions this vehicle has experinced//
    public int GetCollisionCount() => _collisionCount;

    //Resets collision counter to zero//
    public void ResetCollision() => _collisionCount = 0;
}
