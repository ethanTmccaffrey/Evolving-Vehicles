using UnityEngine;

public class FuelCollect : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.CompareTag("Player"))
        {
            //Debug test//
            //Debug.Log($"[FUEL-PICKUP] {collision.gameObject.name} collecting fuel at {collision.transform.position.x}m");

            //Try to refil the specific vehicles fuel//
            VehicleFuelController vehicleFuel = collision.gameObject.GetComponentInParent<VehicleFuelController>();
            if (vehicleFuel != null)
            {
                //Debug.Log($"[FUEL-REFILL-ATTEMPT] Found VehicleFuelController, calling FillFuel()");
                vehicleFuel.FillFuel();
            }
            else
            {
                Debug.Log($"[FUEL-ERROR] VehicleFuelController is NULL! Using global fuel instead");

                //Fall back to global fuel controller for manual play//
                if (FuelController.instance != null)
                {
                    FuelController.instance.FillFuel();
                }
            }
            //Destroy(gameObject);
        }
    }
}
