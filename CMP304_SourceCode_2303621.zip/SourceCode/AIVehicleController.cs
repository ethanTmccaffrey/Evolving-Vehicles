using UnityEngine;

/*
controls how each of the individual vehicles behaves during the Genetic Algorithm generations,
It reads each of the current vehicles current game state including the fuel, speed and slope values. Then uses DNA to decide what actions to take.
This file also tracks the performance of each individual vehicles performance metrics to be used for fitness calculations.
*/

public class AIVehicleController : MonoBehaviour
{
    //Control vehicle movement and physics//
    [SerializeField] private DriveCar _driveCar;
    [SerializeField] private Rigidbody2D _carRB;
    [SerializeField] private VehicleFuelController _VehicleFuelController;
    [SerializeField] private Transform _groundCheckPoint;
    [SerializeField] private float _groundCheckDistance = 5f;

    private VehicleDNA _dna;
    private RunData _runData;
    private bool _isAlive = true;
    private float _startTime;
    private Vector2 _startPosition;
    private int _checkpointsReached = 0;
    private float _checkpointInterval = 50f;

    //Stuck detection variables//
    private float _stuckTimer = 0f;
    private float _maxStuckTime = 0f;
    private float _lastPosition = 0f;
    private float _positionCheckInterval = 2.5f;
    private float _positionCheckTimer = 0f;
    private float _graceTimer = 0f;
    private float _gracePeriod = 3f;

    //Initialise the AI Vehicle with DNA from the genetic algorithm//
    public void Initialize(VehicleDNA dna)
    {
        _dna = dna;
        _runData = new RunData();
        _driveCar.SetAIControlled(true);
        _isAlive = true;
        _startTime = Time.time;
        _startPosition = transform.position;
        _checkpointsReached = 0;

        //Reset driver death from head//
        DriverDeathFromHead deathScript = GetComponent<DriverDeathFromHead>();
        if (deathScript != null)
        {
            deathScript.ResetCollision();
        }
        //DEBUG TEST LINE//
        Debug.Log($"[INIT] {gameObject.name} initialized at time {_startTime}");

        //Initialise stuck detection//
        _stuckTimer = 0f;
        _maxStuckTime = 0f;
        _lastPosition = _startPosition.x;
        _positionCheckTimer = 0f;
        _graceTimer = 0f;

        //Find the fuel controller if not assigned//
        if (_VehicleFuelController == null)
        {
            _VehicleFuelController = GetComponent<VehicleFuelController>();
        }
        //DEBUG LINES FOR TESTING//
        //Debug.Log("AI vehicle Initialised with random DNA");

        //Validate all required components//
        if (_driveCar == null) Debug.LogError("DriveCar is null");
        if (_carRB == null) Debug.LogError("carRB is null");
        if (_VehicleFuelController == null) Debug.LogError("VehicleFuelController is null");
        if (_groundCheckPoint == null) Debug.LogError("GroundCheckpoint is null");
    }

    //called at fixed time intervals for physics calculations//
    //Analyzes the game state and applies DNA actions//
    private void FixedUpdate()
    {
        if (_dna == null || !_isAlive) return;

        if (_carRB == null)
        {
            //DEBUG LINES FOR TESTING//
            Debug.LogError("carRB is not assigned in AIVehicleController");
            return;
        }
        if (_VehicleFuelController == null)
        {
            //DEBUG LINES FOR TESTING//
            Debug.LogError("FuelController is not available");
            return;
        }
        if (_groundCheckPoint == null)
        {
            //DEBUG LINES FOR TESTING//
            Debug.LogError("GroundCheckpoint is not assigned in AIVehicleController");
            return;
        }


        //Get current state//
        float fuelPercent = _VehicleFuelController.GetFuelPercent();
        VehicleGameState state = VehicleGameState.AnalyzeState(_carRB, fuelPercent, _groundCheckPoint, _groundCheckDistance);

        //get action from DNA//
        int stateIndex = state.GetStateIndex();
        VehicleAction action = _dna.GetActionForState(stateIndex);

        //Apply action//
        action.ApplyAction(_driveCar, _carRB, 150f, 50f);

        //Check for checkpoints//
        CheckIndividualPoints();

        //Check if stuck//
        CheckIfStuck();
    }

    //Check if the vehicle is stuck//
    private void CheckIfStuck()
    {
        //grace period dont check if stuck at the very start//
        _graceTimer += Time.fixedDeltaTime;

        //Skip stuck detection during grace period//
        if (_graceTimer < _gracePeriod)
        {
            return;
        }

        //track velocity for immediate stuck detection//
        float currentSpeed = _carRB.linearVelocity.magnitude;

        if(currentSpeed < 1f)
        {
            _stuckTimer += Time.fixedDeltaTime;

            if(_stuckTimer > _maxStuckTime)
            {
                _maxStuckTime = _stuckTimer;
            }
        }
        else
        {
            _stuckTimer = 0;
        }

        //Check position based progress every 2 seconds//
        _positionCheckTimer += Time.fixedDeltaTime;

        if(_positionCheckTimer >= _positionCheckInterval)
        {
            float currentPosition = transform.position.x;
            float progressMade = currentPosition - _lastPosition;

            //if vehicle moved less than 2m in 2.5 seconds its stuck//
            if(progressMade < 2f)
            {
                //if stuck for 8 seconds total kill it//
                if(_maxStuckTime >= 8f)
                {
                    //DEBUG TEST LINE//
                    Debug.Log($"[STUCK DEATH] {gameObject.name} stuck at {currentPosition:F1}, for {_maxStuckTime:F1}s - terminating vehicle ");
                    _runData.gotStuck = true;
                    _runData.timeStuck = _maxStuckTime;
                    Die();
                    return;
                }
            }
            _lastPosition = currentPosition;
            _positionCheckTimer = 0;
        }
    }

    //Returns wether this vehicle is currently alive and active//
    public bool IsAlive() => _isAlive;

    //Marks the vehicle as dead and collects final performance data//
    //Prevents duplicate death calls with early exit if already dead//
    public void Die()
    {
        //Prevent double death//
        if(!_isAlive)
        {
            //DEBUG LINES FOR TESTING//
            //Debug.LogWarning($"[DIE-DOUBLE] {gameObject.name} Die() called but already dead");
            return;
        }
        //DEBUG LINES FOR TESTING//
        //Debug.Log($"[DIE] {gameObject.name} died at {transform.position.x}m");

        _isAlive = false;

        //Collect final run data//
        float currentTime = Time.time;
        _runData.timeTaken = currentTime - _startTime;
        Debug.Log($"[DIE-TIME] {gameObject.name} died. Start={_startTime}, Current={currentTime}, Duration={_runData.timeTaken:F2}s");
        _runData.distanceTraveled = transform.position.x;
        _runData.checkpointsReached = _checkpointsReached;

        DriverDeathFromHead deathScript = GetComponent<DriverDeathFromHead>();
        if(deathScript != null)
        {
            _runData.headCollisions = deathScript.GetCollisionCount();
        }

        //Use per-vehicle fuel//
        if (_VehicleFuelController != null)
        {
            _runData.fuelConsumed = 100f - (_VehicleFuelController.GetFuelPercent() * 100f);
        }
        //DEBUG LINES FOR TESTING//
        //Debug.Log($"[AI Death] Distance: {_runData.distanceTraveled:F1`}m | Time: {_runData.timeTaken:F1}s | Checkpoints: {_runData.checkpointsReached} | Collision: {_runData.headCollisions}");

        //Record stuck time if vehicle was stuck//
        _runData.timeTaken = _maxStuckTime;
        if(_maxStuckTime > 8f)
        {
            _runData.gotStuck = true;
        }
    }

    //Called when vehicle crosses the finish line//
    //Marks the run as completed the collects final data//
    public void completedLevel()
    {
        if(!_isAlive)
        {
            //DEBUG LINES FOR TESTING//
            //Debug.LogWarning($"[COMPLETE-ALREADY-DEAD] {gameObject.name} tried to complete but already dead");
            return;
        }
        //DEBUG LINES FOR TESTING//
        //Debug.Log($"[COMPLETED-LEVEL] {gameObject.name} finished at {transform.position.x}m in {Time.time - _startTime:F1}s");

        //Mark as complete before collecting final data//
        _runData.completedLevel = true;

        //Now collect the final stats//
        Die();
    }

    //Returns the collected performance data for this vehicles run//
    public RunData GetRunData() => _runData;

    //Unity lifecycle method called when object is destroyed//
    private void OnDestroy()
    {
        //Record final data//
        if (_runData != null)
        {
            _runData.timeTaken = Time.time - _startTime;
            _runData.distanceTraveled = transform.position.x;
        }
    }

    //Checks if vehicle has passed the next checkpoint based on X positions//
    private void CheckIndividualPoints()
    {
        //Check if vehicle has passed the next checkpint//
        float nextCheckpoint = (_checkpointsReached + 1) * _checkpointInterval;

        if(transform.position.x >= nextCheckpoint)
        {
            _checkpointsReached++;
            //DEBUG LINES FOR TESTING//
            //Debug.Log($"[CHECKPOINT] {gameObject.name} reached checpoint {_checkpointsReached} at {transform.position.x:F1}m");
        }
    }

}
