using UnityEngine;
using System.Collections.Generic;

public class FuelSpawner : MonoBehaviour
{
    [SerializeField] private GameObject _fuelPrefab;
    [SerializeField] private Transform _ground;
    [SerializeField] private int _numberOfFuelCans = 200;
    [SerializeField] private float _minSpawnDistance = 20f;
    [SerializeField] private float _maxSpawnDistance  = 50;
    [SerializeField] private float _heightAboveGround = 1.5f;
    [SerializeField] private float _levelLength = 3600;

    //keep track of spawned fuel cans so they can be destroyed//
    private List<GameObject> _spawnedFuelCans = new List<GameObject>();
    private void Start()
    {
        SpawnFuelCans();
    }

    public void RespawnFuelCans()
    {
        //Destroy all existing fuel cans//
        ClearFuelCans();

        //Spawn fuel cans//
        SpawnFuelCans();

        //Debug.Log($"Respawned {_spawnedFuelCans.Count} fuel cans");
    }

    public void ClearFuelCans()
    {
        //Collect all fuel cans destroyed/alive //
        FuelCollect[] allFuelCans = FindObjectsOfType<FuelCollect>();

        foreach(FuelCollect fuelCan in allFuelCans)
        {
            if(fuelCan != null)
            {
                Destroy(fuelCan.gameObject);
            }
        }
        //Clear the tracking list//
        _spawnedFuelCans.Clear();

        //Debug.Log($"Cleared {allFuelCans} fuel cans from scene");
    }

    private void SpawnFuelCans()
    {
        float currentX = _minSpawnDistance;

        for(int i = 0; i < _numberOfFuelCans; i++)
        {
            //Random distance for next spawn//
            float spawnX = currentX + Random.Range(_minSpawnDistance, _maxSpawnDistance);

            //Dont spawn past the level length//
            if(spawnX >= _levelLength)
            {
                break;
            }

            //Get the ground height at the x position using raycast//
            Vector2 rayStart = new Vector2(spawnX, 100f);
            RaycastHit2D hit = Physics2D.Raycast(rayStart, Vector2.down, Mathf.Infinity);

            if (hit.collider != null && hit.collider.CompareTag("Ground"))
            {
                //Spawn fuel can slightly above ground//
                Vector3 spawnPos = new Vector3(spawnX, hit.point.y + _heightAboveGround, 0f);
                GameObject fuelCan = Instantiate(_fuelPrefab, spawnPos, Quaternion.identity);

                //Track spawned fuel cans//
                _spawnedFuelCans.Add(fuelCan);
            }

            currentX = spawnX;
        }

        //Debug.Log($"Spawned {_spawnedFuelCans.Count} fuel cans up to {currentX:F0}m");
    }
}
