using UnityEngine;
using System;

[Serializable]
public class RunData
{
    public float distanceTraveled;
    public float timeTaken;
    public float fuelConsumed;
    public float checkpointsReached;
    public float headCollisions;
    public bool completedLevel;
    public bool gotStuck;
    public float timeStuck;

    //Calculated Metrics//
    public float averageSpeed => timeTaken > 0 ? distanceTraveled / timeTaken : 0;
    public float fuelEfficiency => fuelConsumed > 0 ? distanceTraveled / fuelConsumed : 0;

    public RunData()
    {
        distanceTraveled = 0f;
        timeTaken = 0f;
        fuelConsumed = 0f;
        checkpointsReached = 0f;
        headCollisions = 0f;
        completedLevel = false;
        gotStuck = false;
        timeStuck = 0f;
    }
}
