using System.Collections.Generic;
using UnityEngine;

public class CheckpointManager : MonoBehaviour
{
    public static CheckpointManager Instance;

    [SerializeField] private GameObject _checkpointPrefab;
    [SerializeField] private float _checkpointInterval = 50f;
    [SerializeField] private float _levelLength = 3600f;

    private List<float> _checkpointPositions = new List<float>();
    private int _checkpointReached = 0;


    void Awake()
    {
        if (Instance == null) Instance = this;
    }

    void Start()
    {
        SpawnCheckpoints();
    }

    void SpawnCheckpoints()
    {
        for (float x = _checkpointInterval; x < _levelLength; x += _checkpointInterval)
        {
            _checkpointPositions.Add(x);
        }
    }

    public void CheckPosition(float xPosition)
    {
        if (_checkpointReached < _checkpointPositions.Count)
        {
            if (xPosition >= _checkpointPositions[_checkpointReached])
            {
                _checkpointReached++;
                //Debug.Log("Checkpoint " + _checkpointReached + " reached!");
            }
        }
    }

    public int GetCheckpointsReached() => _checkpointReached;
    public void resetCheckpoints() => _checkpointReached = 0;
}
